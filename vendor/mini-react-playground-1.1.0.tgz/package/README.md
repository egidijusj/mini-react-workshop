# Playground for MiniReact workshop

This is the UI environment app for the [MiniReact workshop](https://github.com/egidijusj/mini-react-workshop).

To get started, run:

```
npm i
npm run dev
```